!
! V7/x86 syscall trampoline in ACK i386 assembler syntax.
! Issues `int $0x30` with EAX = syscall number; on EFLAGS.CF set, copies
! errno from EAX and returns -1. Mirrors Nordier's V7 a.out libc/sys/*.s
! conventions but written for ACK's i386 as.
!
! Adapted from Nordier's usr/src/libc/sys/*.s (preserved alongside as
! v7-syscalls.s.nordier for reference) and from the syscall stubs in
! reconstruction/host-toolchain/v7-libsys.s of the v7x86-32 project.

.sect .text; .sect .rom; .sect .data; .sect .bss

.sect .text

! cerror sets errno from EAX and returns -1 (V7 convention).
.define cerror
cerror:
	mov	(_errno),eax
	mov	eax,-1
	ret

.sect .bss
.define _errno
.comm _errno,4
