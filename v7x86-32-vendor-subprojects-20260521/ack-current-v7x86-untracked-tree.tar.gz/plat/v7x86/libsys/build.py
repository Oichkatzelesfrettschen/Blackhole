from build.ack import ackclibrary
from glob import glob

ackclibrary(
    name="libsys",
    plat="v7x86",
    srcs=glob("plat/v7x86/libsys/*.s"),
    deps=["lang/cem/libcc.ansi/headers", "plat/v7x86/include"],
)
