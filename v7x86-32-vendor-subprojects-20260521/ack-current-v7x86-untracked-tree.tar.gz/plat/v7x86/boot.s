!
! V7/x86 boot startup for ACK-built programs.
!
! Targets V7 a.out 0410 (NMAGIC) executables run by Nordier's V7 kernel.
! The kernel sets up the stack with argv as null-terminated array; we
! scan to compute argc and synthesize an ACK-style stack frame for main.
!
! Written for ACK's i386 assembler syntax (Intel-style: dst,src order).

.sect .text; .sect .rom; .sect .data; .sect .bss

.sect .text
.define begtext
begtext:
	! TODO: real V7 entry-point semantics; this is a placeholder so the
	! plat compiles end-to-end. Real entry chains MBR -> pcuboot -> /boot
	! -> kernel which sets up argc/argv/envp before invoking begtext.
	jmp	begtext
