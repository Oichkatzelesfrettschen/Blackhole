from build.ab import export
from build.ack import ackcfile, exportheaders
from mach.proto.ncg.build import build_ncg
from plat.build import build_plat_libs
import importlib

build_as = importlib.import_module("mach.proto.as.build").build_as

# Use the i386 frontend assembler (Intel-syntax input) for hosted builds.
# The Nordier asx assembler runs *after* this stage in the v7x86-32 toolchain;
# see reconstruction/host-toolchain in the parent project for the .s -> V7 a.out
# step. For purely-ACK builds we keep the i386 .o intermediate format.
build_as(name="as", arch="i386")

# Backend: Nordier-flavored i386 ncg.
build_ncg(name="ncg", arch="v7x86")

build_plat_libs(name="plat_libs", arch="i386", plat="v7x86")

ackcfile(name="boot", srcs=["./boot.s"], plat="v7x86")

export(
    name="tools",
    items={
        "$(PLATDEP)/v7x86/as$(EXT)": ".+as",
        "$(PLATDEP)/v7x86/ncg$(EXT)": ".+ncg",
        "$(PLATIND)/descr/v7x86": "./descr",
    },
)

export(
    name="all",
    items={
        "$(PLATIND)/v7x86/boot.o": ".+boot",
        "$(PLATIND)/v7x86/libsys.a": "./libsys",
    },
    deps=[
        ".+tools",
        ".+plat_libs",
        "util/ack+all",
        "plat/v7x86/include+all",
    ],
)
