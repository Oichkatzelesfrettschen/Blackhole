/* V7/x86 platform configuration for ACK.
 * See: vendor/ack-current/plat/linux/include/ack/plat.h for the analog.
 *
 * V7 lacks the modern POSIX flags that linux gets; ACK adapts where
 * possible.  Reference COPYRIGHT for license.
 */
#ifndef _V7X86_ACK_PLAT_H
#define _V7X86_ACK_PLAT_H

#define ACKCONF_WANT_STANDARD_O          0
#define ACKCONF_WANT_STANDARD_SIGNALS    0

/* V7 has no termios; pre-POSIX sgtty is the only TTY API. */
#define ACKCONF_WANT_STANDARD_TERMIOS    0

/* V7 errno header layout */
#define ACKCONF_WANT_STANDARD_ERRNOS     0

#endif
