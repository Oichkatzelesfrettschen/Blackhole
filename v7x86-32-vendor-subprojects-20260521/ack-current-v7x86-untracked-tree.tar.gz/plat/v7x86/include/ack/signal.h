/* V7/x86 ack/signal.h - V7 signal definitions for ACK.
 *
 * V7 has only 15 signals (SIGHUP through SIGTERM); modern POSIX renamed
 * SIGIOT to SIGABRT, so we provide that alias.  These constants are
 * pulled directly from V7's /usr/include/signal.h to avoid recursing
 * through ACK's libcc.ansi/headers/signal.h.
 *
 * Reference: usr/include/signal.h in the Nordier V7/x86 0.8a distro.
 */
#ifndef _V7X86_ACK_SIGNAL_H
#define _V7X86_ACK_SIGNAL_H

#define NSIG    17
#define _NSIG   17

#define SIGHUP   1   /* hangup */
#define SIGINT   2   /* interrupt */
#define SIGQUIT  3   /* quit */
#define SIGILL   4   /* illegal instruction (not reset when caught) */
#define SIGTRAP  5   /* trace trap (not reset when caught) */
#define SIGIOT   6   /* IOT instruction */
#define SIGABRT  6   /* alias for SIGIOT (ANSI) */
#define SIGEMT   7   /* EMT instruction */
#define SIGFPE   8   /* floating point exception */
#define SIGKILL  9   /* kill (cannot be caught or ignored) */
#define SIGBUS  10   /* bus error */
#define SIGSEGV 11   /* segmentation violation */
#define SIGSYS  12   /* bad argument to system call */
#define SIGPIPE 13   /* write on a pipe with no one to read it */
#define SIGALRM 14   /* alarm clock */
#define SIGTERM 15   /* software termination signal from kill */

typedef int sig_atomic_t;
typedef unsigned short sigset_t;

#define SIG_ERR ((sighandler_t) -1)
#define SIG_DFL ((sighandler_t) 0)
#define SIG_IGN ((sighandler_t) 1)

#endif
