/* V7/x86 fcntl - V7 predates POSIX fcntl. Bare-minimum constants are
 * defined here so ACK's libc/* sources compile; runtime behavior depends
 * on V7 kernel which only honors open() flags 0/1/2 (read/write/rdwr).
 */
#ifndef _V7X86_ACK_FCNTL_H
#define _V7X86_ACK_FCNTL_H

#define O_RDONLY 0
#define O_WRONLY 1
#define O_RDWR   2
#define O_CREAT  0100   /* V7 syscall 8 -- creat is separate */
#define O_APPEND 02000  /* (post-V7 extension) */
#define O_TRUNC  01000

#endif
