from build.ab import export
from build.ack import exportheaders, clibrary
from glob import glob

# v7x86 platform headers - self-contained, sourced from Nordier's V7/x86
# 0.8a usr/include/ tree.  No dependency on plat/linux/* (de-contamination).
headers = glob("**/*.h", root_dir="plat/v7x86/include", recursive=True)

clibrary(name="include", hdrs={k: f"./{k}" for k in headers})

export(
    name="all",
    items=exportheaders(".+include", prefix="$(PLATIND)/v7x86/include"),
)
