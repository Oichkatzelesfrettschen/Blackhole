/* V7/x86 sys/ioctl.h - V7 lacks a unified ioctl header; routes to sgtty.h
 * for terminal ioctls and to ack/plat.h for nothing-else.
 */
#ifndef _V7X86_SYS_IOCTL_H
#define _V7X86_SYS_IOCTL_H

#include <sgtty.h>

#endif
