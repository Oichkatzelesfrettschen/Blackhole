/* V7/x86 sys/types.h - V7-specific types only.
 *
 * Standard ANSI types (size_t, ssize_t, off_t) are provided by ACK's
 * libcc.ansi/headers/{stddef.h, stdint.h}; we don't redefine them.
 * POSIX types (pid_t, mode_t, suseconds_t) ACK needs but V7 lacks are
 * provided here.
 */
#ifndef _V7X86_SYS_TYPES_H
#define _V7X86_SYS_TYPES_H

/* Pull standard types from ACK's headers. */
#include <stddef.h>
#include <stdint.h>

/* V7-original types. */
typedef long           daddr_t;   /* disk address */
typedef char *         caddr_t;   /* core address */
typedef unsigned short ino_t;     /* i-node number */
typedef long           time_t;    /* a time (seconds since epoch) */
typedef int            label_t[6]; /* program status */
typedef short          dev_t;     /* device code */

/* POSIX extensions ACK expects but V7 lacks. */
typedef int            pid_t;
typedef unsigned short mode_t;
typedef long           suseconds_t;

#define major(x)       ((int)(((unsigned)(x)) >> 8))
#define minor(x)       ((int)((x) & 0377))
#define makedev(x,y)   ((dev_t)((x) << 8 | (y)))

#endif /* _V7X86_SYS_TYPES_H */
