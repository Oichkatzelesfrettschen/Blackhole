/* V7/x86 sys/wait.h - V7 wait() returns a single int; POSIX macros below
 * decode it into status/signal portions.
 */
#ifndef _V7X86_SYS_WAIT_H
#define _V7X86_SYS_WAIT_H

extern int wait();

/* V7 wait status encoding: low byte = signal+core flag, high byte = exit code */
#define WEXITSTATUS(status)  (((status) >> 8) & 0xff)
#define WTERMSIG(status)     ((status) & 0x7f)
#define WIFEXITED(status)    (((status) & 0xff) == 0)
#define WIFSIGNALED(status)  (((status) & 0x7f) != 0 && WTERMSIG(status) != 0x7f)
#define WIFSTOPPED(status)   (((status) & 0xff) == 0x7f)

#endif
