/*
 * Mach Device Interface Header
 * Minimal stub for Lites 1.1.u3 build
 *
 * This header provides Mach device management declarations.
 */

#ifndef _DEVICE_DEVICE_H_
#define _DEVICE_DEVICE_H_

#include <mach/kern_return.h>
#include <mach/port.h>
#include <mach/message.h>

/* Device port type */
typedef mach_port_t device_t;

/* Device mode flags */
typedef int dev_mode_t;

#define D_READ		0x01
#define D_WRITE		0x02
#define D_NODELAY	0x04

/* Device flavor */
typedef int dev_flavor_t;

/* Record number type and buffer pointer - define before use */
typedef int recnum_t;
typedef char *io_buf_ptr_t;

/* Basic device operations */
extern kern_return_t device_open(
    mach_port_t master_port,
    dev_mode_t mode,
    char *name,
    device_t *device);

extern kern_return_t device_close(
    device_t device);

extern kern_return_t device_read(
    device_t device,
    dev_mode_t mode,
    recnum_t recnum,
    int bytes_wanted,
    io_buf_ptr_t *data,
    mach_msg_type_number_t *data_count);

extern kern_return_t device_write(
    device_t device,
    dev_mode_t mode,
    recnum_t recnum,
    io_buf_ptr_t data,
    mach_msg_type_number_t data_count,
    int *bytes_written);

#endif /* _DEVICE_DEVICE_H_ */
