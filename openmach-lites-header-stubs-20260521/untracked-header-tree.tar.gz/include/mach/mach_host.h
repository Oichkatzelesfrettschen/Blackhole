/*
 * Mach Host Interface Header
 * Minimal stub for Lites 1.1.u3 build
 *
 * This header provides Mach host management interface declarations.
 */

#ifndef _MACH_MACH_HOST_H_
#define _MACH_MACH_HOST_H_

#include <mach/kern_return.h>
#include <mach/port.h>
#include <mach/host_info.h>
#include <mach/machine.h>

/* Host control functions */
extern kern_return_t host_info(
    host_t host_priv,
    int flavor,
    host_info_t host_info_out,
    mach_msg_type_number_t *host_info_count);

extern kern_return_t host_kernel_version(
    host_t host,
    kernel_version_t kernel_version);

extern kern_return_t host_page_size(
    host_t host,
    vm_size_t *page_size);

extern kern_return_t host_get_clock_service(
    host_t host,
    int clock_id,
    mach_port_t *clock_serv);

extern kern_return_t host_get_time(
    host_t host,
    time_value_t *current_time);

extern kern_return_t host_adjust_time(
    host_priv_t host_priv,
    time_value_t new_adjustment,
    time_value_t *old_adjustment);

extern kern_return_t host_get_boot_info(
    host_priv_t host_priv,
    kernel_boot_info_t boot_info);

#endif /* _MACH_MACH_HOST_H_ */
