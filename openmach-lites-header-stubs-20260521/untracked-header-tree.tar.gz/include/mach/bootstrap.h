/*
 * Mach Bootstrap Interface Header
 * Minimal stub for Lites 1.1.u3 build
 *
 * This header provides Mach bootstrap server interface declarations.
 */

#ifndef _MACH_BOOTSTRAP_H_
#define _MACH_BOOTSTRAP_H_

#include <mach/kern_return.h>
#include <mach/port.h>

/* Bootstrap port operations */
extern kern_return_t bootstrap_create_service(
    mach_port_t bootstrap_port,
    char *service_name,
    mach_port_t *service_port);

extern kern_return_t bootstrap_check_in(
    mach_port_t bootstrap_port,
    char *service_name,
    mach_port_t *service_port);

extern kern_return_t bootstrap_look_up(
    mach_port_t bootstrap_port,
    char *service_name,
    mach_port_t *service_port);

extern kern_return_t bootstrap_register(
    mach_port_t bootstrap_port,
    char *service_name,
    mach_port_t service_port);

#endif /* _MACH_BOOTSTRAP_H_ */
