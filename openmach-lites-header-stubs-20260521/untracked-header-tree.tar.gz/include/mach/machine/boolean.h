/*
 * Mach Operating System
 * Copyright (c) 1991,1990,1989 Carnegie Mellon University
 * All Rights Reserved.
 *
 * Machine-specific boolean type definition
 * For i386 architecture
 */

#ifndef _MACH_MACHINE_BOOLEAN_H_
#define _MACH_MACHINE_BOOLEAN_H_

#include <mach/machine_types.h>

/* boolean_t is defined in machine_types.h */

#endif /* _MACH_MACHINE_BOOLEAN_H_ */
