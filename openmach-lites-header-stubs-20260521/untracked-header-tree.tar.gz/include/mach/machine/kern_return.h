/*
 * Mach Operating System
 * Copyright (c) 1991,1990,1989 Carnegie Mellon University
 * All Rights Reserved.
 *
 * Machine-specific kern_return_t type definition
 * For i386 architecture
 */

#ifndef _MACH_MACHINE_KERN_RETURN_H_
#define _MACH_MACHINE_KERN_RETURN_H_

#include <mach/machine_types.h>

/* kern_return_t is defined in machine_types.h as integer_t */

#endif /* _MACH_MACHINE_KERN_RETURN_H_ */
