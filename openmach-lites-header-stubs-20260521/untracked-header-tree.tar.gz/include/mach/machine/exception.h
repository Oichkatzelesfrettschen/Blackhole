/*
 * Mach Operating System
 * Copyright (c) 1991,1990,1989 Carnegie Mellon University
 * All Rights Reserved.
 *
 * Machine-specific exception definitions
 * For i386 architecture
 */

#ifndef _MACH_I386_EXCEPTION_H_
#define _MACH_I386_EXCEPTION_H_

#include <mach/machine_types.h>

/*
 * EXC_TYPES_COUNT represents the number of exception types.
 * EXC_TYPES_COUNT must be consistent with the number of exception
 * types defined in <mach/exception.h>
 */
#define EXC_TYPES_COUNT 10

/*
 * i386-specific exception codes for EXC_BAD_ACCESS
 */
#define EXC_I386_SRL    0       /* segment not present */
#define EXC_I386_PGFLT  1       /* page fault */
#define EXC_I386_ALIGN  2       /* alignment check */

/*
 * i386-specific exception codes for EXC_BAD_INSTRUCTION
 */
#define EXC_I386_INVOP  1       /* invalid opcode */

/*
 * i386-specific exception codes for EXC_ARITHMETIC
 */
#define EXC_I386_DIV    1       /* divide by zero */
#define EXC_I386_INTO   2       /* INTO overflow */
#define EXC_I386_BOUND  3       /* BOUND range check */
#define EXC_I386_NOEXT  4       /* coprocessor not available */
#define EXC_I386_EXTOVR 5       /* coprocessor segment overrun */
#define EXC_I386_EMERR  6       /* coprocessor error */
#define EXC_I386_EXTERR 7       /* coprocessor external error */

/*
 * Unix signal compatibility exception codes
 * These map Mach exceptions to traditional Unix signal codes
 */
#define ILL_RESOP_FAULT  1      /* reserved operand fault */
#define FPE_INTOVF_TRAP  1      /* integer overflow trap */
#define FPE_INTDIV_TRAP  2      /* integer divide by zero trap */
#define FPE_SUBRNG_TRAP  3      /* subscript out of range trap */

#endif /* _MACH_I386_EXCEPTION_H_ */
