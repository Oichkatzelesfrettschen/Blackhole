/*
 * Mach Port Management Header
 * Minimal stub for Lites 1.1.u3 build
 *
 * This header provides Mach port management function declarations.
 * Type definitions come from <mach/port.h> which is already included.
 */

#ifndef _MACH_MACH_PORT_H_
#define _MACH_MACH_PORT_H_

#include <mach/port.h>
#include <mach/kern_return.h>
#include <mach/message.h>

/*
 * Port rights and attributes are already defined in <mach/port.h>
 * This stub just provides the header structure for compatibility.
 */

/* Port attributes */
typedef int mach_port_flavor_t;
typedef natural_t *mach_port_info_t;

#endif /* _MACH_MACH_PORT_H_ */
