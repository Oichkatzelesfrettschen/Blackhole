/*
 * Mach Machine-Independent Type Definitions
 * For Lites 1.1.u3 on CMU Mach 3.0
 *
 * Based on standard Mach 3.0 type conventions
 */

#ifndef _MACH_MACHINE_TYPES_H_
#define _MACH_MACHINE_TYPES_H_

/*
 * Basic Mach integer types
 * These are machine-independent and used throughout Mach IPC
 */
typedef int                integer_t;
typedef unsigned int       natural_t;
typedef int                boolean_t;

/*
 * Common Mach type aliases
 */
typedef integer_t          kern_return_t;
typedef integer_t          mach_msg_return_t;

/*
 * Boolean constants
 */
#ifndef TRUE
#define TRUE  1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#endif /* _MACH_MACHINE_TYPES_H_ */
